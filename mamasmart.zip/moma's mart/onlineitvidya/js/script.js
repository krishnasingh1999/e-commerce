
// navbar

window.onscroll = () => {
    const nav = document.querySelector('#navbar');
    if(this.scrollY <= 10) nav.className = ''; else nav.className = 'scroll';
  };



// courses category

  window.addEventListener('DOMContentLoaded', function(e) {
    $('.carousel-cat').slick({
      slidesToShow: 3,
      prevArrow: '<button class="previous-button is-control">' +
                 '  <span class="fas fa-angle-left" aria-hidden="true"></span>' +
                 '  <span class="sr-only">Previous slide</span>' +
                 '</button>',
      nextArrow: '<button class="next-button is-control">' +
                 '  <span class="fas fa-angle-right" aria-hidden="true"></span>' +
                 '  <span class="sr-only">Next slide</span>' +
                 '</button>',
      responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 2
          }
        },
        {
          breakpoint: 575,
          settings: {
            slidesToShow: 1
          }
        }
      ]
    });
  });